import React, { useState } from 'react'
import {Users,UserPlus,UserCheck,UserRoundPen,MessageSquare} from 'lucide-react'
import { 
  dummyConnectionsData as connections, 
  dummyFollowersData as followers,
  dummyFollowingData as following,
  dummyPendingConnectionsData as pendingConnections
} from '../assets/assets'

import { useNavigate } from 'react-router-dom';

const Connection = () => {

  const [currentTab, setCurrentTab] = useState('Người theo dõi');

  const navigate = useNavigate();

  const dataArray = [
    {lable: 'Người theo dõi', value: followers, icon: Users },
    {lable: 'Đang theo dõi', value: following, icon: UserCheck },
    {lable: 'Chờ Chấp Nhận', value: pendingConnections, icon: UserRoundPen },
    {lable: 'Thêm Bạn', value: connections, icon: UserPlus },
  ]

  return (
    <div className='min-h-screen bg-slate-50'>
       <div className='max-w-6xl mx-auto p-6'>
          {/* Tiêu Đề */}
          <div className='mb-8'>
            <h1 className='text-3xl font-bold text-slate-900 mb-2'>Thêm bạn</h1>
            <p className='text-slate-600'>kết nối mọi người với nhau</p>
          </div>
          {/* count */}
          <div className='mb-8 flex flex-wrap gap-6'>
            {dataArray.map((item,index)=>(
              <div key={index} className='flex flex-col items-center justify-center gap-1 border h-20 w-40 border-gray-200 bg-white rounded-md shadow'>
                <b>{item.value.length}</b>
                <p className='text-slate-600'>{item.lable}</p>
              </div>
            ))}
          </div>    

          {/* Nội Dung Kết Nối */}
          <div className='inline-flex flex-wrap items-center border border-gray-200 rounded-md p-1 bg-white shadow-sm'>
            {dataArray.map((tab)=>(
              <button onClick={()=> setCurrentTab(tab.lable)} key={tab.lable} className={`flex items-center px-3 py-1 text-sm rounded-md transition-colors
              ${currentTab === tab.lable ? 'bg-white font-medium text-black' : 'text-gray-500 hover:text-black'}`}>
                <tab.icon className='w-4 h-4'/>
                <span className='ml-1' onClick={()=>setCurrentTab(tab.lable)}>{tab.lable}</span>
                {tab.count !== undefined && (
                  <span className='ml-2 text-xs bg-gray-100 text-gray-700 px-2 py-0.5 rounded-full'>{tab.count}</span>
                )}
              </button>
            ))}
          </div>


            {/* Them ban */}
            <div className='flex flex-wrap gap-6 mt-6'>
              {dataArray.find((item)=> item.lable === currentTab).value.map((user)=>(
                <div key={user._id} className='w-full max-w-88 flex gap-5 p-6 bg-white shadow rounded-md'>
                  <img src={user.profile_picture} alt="" className='rounded-full w-12 h-12 shadow-md mx-auto'/>
                  <div className='flex-1'>
                    <p className='font-medium text-slate-700'>{user.full_name}</p>
                    <p className='text-slate-500'>@{user.full_name}</p>
                    <p className='text-slate-500'>{user.bio.slice(0,30)}...</p>
                    <div className='flex max-sm:flex-col gap-2 mt-4'>
                      {
                        <button onClick={()=> navigate(`/profile/${user._id}`)} 
                        className='w-full p-2 text-sm rounded bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600
                        hover:to-purple-700 active:scale-95 transition text-white cursor-pointer'>
                          Trang Cá Nhân
                        </button>
                      }
                      {
                        currentTab === 'Đang theo dõi' && (
                          <button className='w-full p-2 text-sm rounded bg-slate-100 hover:bg-slate-200 text-black active:scale-95 transition cursor-pointer'>
                            Bỏ Theo Dõi
                          </button>
                        )
                      }

                      {
                        currentTab === 'Chờ Chấp Nhận' && (
                          <button className='w-full p-2 text-sm rounded bg-slate-100 hover:bg-slate-200 text-black active:scale-95 transition cursor-pointer'>
                           Chấp Nhận
                          </button>
                        )
                      }
                      
                      {
                        currentTab === 'Thêm Bạn' && (
                          <button onClick={()=>navigate(`/messages/${user._id}`)} className='w-full p-2 text-sm rounded bg-slate-100 hover:bg-slate-200 text-slate-800 active:scale-95 
                          transition cursor-pointer flex items-center justify-center gap-1'>
                            <MessageSquare className='w-4 h-4 '/>
                            Nhắn Tin
                          </button>
                        )
                      }
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
       </div>
    </div>
  )
}

export default Connection